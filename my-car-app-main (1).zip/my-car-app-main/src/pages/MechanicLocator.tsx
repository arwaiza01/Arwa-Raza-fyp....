import { useState } from 'react';
import { Wrench, Phone, MapPin, Star } from 'lucide-react';
import { mechanics } from '../data/mechanics';
import Card from '../components/Card';
import Button from '../components/Button';

export default function MechanicLocator() {
  const [filterIssue, setFilterIssue] = useState('');

  const filteredMechanics = filterIssue
    ? mechanics.filter(mechanic => mechanic.expertise.includes(filterIssue))
    : mechanics;

  return (
    <div className="min-h-screen bg-[#0f172a]">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-red-500 bg-opacity-10 rounded-full">
              <Wrench size={64} className="text-red-500" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-white mb-4">Mechanic Locator</h1>
          <p className="text-xl text-gray-300">
            Find trusted mechanics near you with verified expertise
          </p>
        </div>

        <Card hover={false} className="mb-8 p-6">
          <h2 className="text-xl font-bold text-white mb-4">Filter by Issue</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {['Engine', 'Brakes', 'Electrical', 'Transmission', 'AC Repair', 'Body Work'].map(issue => (
              <button
                key={issue}
                onClick={() => setFilterIssue(filterIssue === issue ? '' : issue)}
                className={`px-4 py-3 rounded-lg font-medium transition-all ${
                  filterIssue === issue
                    ? 'bg-red-500 text-white'
                    : 'bg-[#0f172a] text-gray-300 hover:bg-gray-700'
                }`}
              >
                {issue}
              </button>
            ))}
          </div>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredMechanics.map(mechanic => (
                <Card key={mechanic.id}>
                  <div className="p-6">
                    <h3 className="text-2xl font-bold text-white mb-3">{mechanic.name}</h3>

                    <div className="flex items-center space-x-2 mb-4">
                      <Star size={20} className="text-yellow-500 fill-yellow-500" />
                      <span className="text-white font-semibold">{mechanic.rating}</span>
                      <span className="text-gray-400">({mechanic.experience})</span>
                    </div>

                    <div className="mb-4">
                      <p className="text-gray-400 text-sm mb-2">Expertise:</p>
                      <div className="flex flex-wrap gap-2">
                        {mechanic.expertise.map((exp, idx) => (
                          <span
                            key={idx}
                            className="px-3 py-1 bg-red-500 bg-opacity-10 text-red-500 rounded-full text-sm font-medium"
                          >
                            {exp}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2 text-gray-300 mb-4">
                      <MapPin size={18} />
                      <span>{mechanic.location}</span>
                    </div>

                    <div className="flex items-center space-x-2 text-gray-300 mb-6">
                      <Phone size={18} />
                      <span>{mechanic.phone}</span>
                    </div>

                    <Button className="w-full" variant="secondary">
                      View on Map
                    </Button>
                  </div>
                </Card>
              ))}
            </div>

            {filteredMechanics.length === 0 && (
              <Card hover={false}>
                <div className="p-12 text-center">
                  <p className="text-gray-400 text-lg">
                    No mechanics found with this expertise. Please try a different filter.
                  </p>
                </div>
              </Card>
            )}
          </div>

          <div className="lg:col-span-1">
            <Card hover={false} className="sticky top-24">
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-4">Location Map</h3>
                <div className="bg-[#0f172a] rounded-lg overflow-hidden">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d435519.2274098007!2d74.00471544639022!3d31.483103655931895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39190483e58107d9%3A0xc23abe6ccc7e2462!2sLahore%2C%20Punjab%2C%20Pakistan!5e0!3m2!1sen!2s!4v1234567890123!5m2!1sen!2s"
                    width="100%"
                    height="400"
                    style={{ border: 0 }}
                    loading="lazy"
                    title="Mechanic Locations"
                  ></iframe>
                </div>
                <p className="text-gray-400 text-sm mt-4">
                  Map showing approximate locations of mechanics in your area
                </p>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
