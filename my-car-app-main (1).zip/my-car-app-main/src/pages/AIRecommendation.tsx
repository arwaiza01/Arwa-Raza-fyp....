import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Brain, Sparkles } from 'lucide-react';
import { cars } from '../data/cars';
import Card from '../components/Card';
import Button from '../components/Button';

export default function AIRecommendation() {
  const navigate = useNavigate();
  const [preferences, setPreferences] = useState({
    budget: '',
    category: '',
    fuelType: ''
  });
  const [recommendation, setRecommendation] = useState<typeof cars[0] | null>(null);

  const handleRecommend = () => {
    let filtered = cars;

    if (preferences.budget) {
      const [min, max] = preferences.budget.split('-').map(Number);
      filtered = filtered.filter(car => {
        if (max) return car.price >= min && car.price <= max;
        return car.price >= min;
      });
    }

    if (preferences.category) {
      filtered = filtered.filter(car => car.category === preferences.category);
    }

    if (preferences.fuelType) {
      filtered = filtered.filter(car => car.fuelType === preferences.fuelType);
    }

    if (filtered.length > 0) {
      const randomIndex = Math.floor(Math.random() * filtered.length);
      setRecommendation(filtered[randomIndex]);
    } else {
      setRecommendation(null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0f172a] to-[#1f2937]">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-sky-500 bg-opacity-10 rounded-full">
              <Brain size={64} className="text-sky-500" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-white mb-4">AI Car Recommendation</h1>
          <p className="text-xl text-gray-300">
            Get personalized car suggestions based on your preferences
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Card hover={false}>
            <div className="p-8">
              <h2 className="text-2xl font-bold text-white mb-6">Tell us your preferences</h2>

              <div className="space-y-6">
                <div>
                  <label className="block text-gray-300 mb-2 font-medium">Budget Range</label>
                  <select
                    value={preferences.budget}
                    onChange={(e) => setPreferences({ ...preferences, budget: e.target.value })}
                    className="w-full bg-[#0f172a] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-sky-500 focus:outline-none"
                  >
                    <option value="">Select Budget</option>
                    <option value="0-3000000">Under 30 Lac</option>
                    <option value="3000000-5000000">30-50 Lac</option>
                    <option value="5000000-8000000">50-80 Lac</option>
                    <option value="8000000-999999999">Above 80 Lac</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 mb-2 font-medium">Car Type</label>
                  <select
                    value={preferences.category}
                    onChange={(e) => setPreferences({ ...preferences, category: e.target.value })}
                    className="w-full bg-[#0f172a] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-sky-500 focus:outline-none"
                  >
                    <option value="">Select Type</option>
                    <option value="Sedan">Sedan</option>
                    <option value="SUV">SUV</option>
                    <option value="Hatchback">Hatchback</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 mb-2 font-medium">Fuel Preference</label>
                  <select
                    value={preferences.fuelType}
                    onChange={(e) => setPreferences({ ...preferences, fuelType: e.target.value })}
                    className="w-full bg-[#0f172a] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-sky-500 focus:outline-none"
                  >
                    <option value="">Select Fuel Type</option>
                    <option value="Petrol">Petrol</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Hybrid">Hybrid</option>
                  </select>
                </div>

                <Button
                  variant="secondary"
                  className="w-full flex items-center justify-center space-x-2"
                  onClick={handleRecommend}
                >
                  <Sparkles size={20} />
                  <span>Recommend Car</span>
                </Button>
              </div>
            </div>
          </Card>

          {recommendation && (
            <div className="mt-8 animate-fade-in">
              <div className="text-center mb-6">
                <h3 className="text-3xl font-bold text-white mb-2">
                  Based on your preferences, we suggest:
                </h3>
                <p className="text-gray-400">This car matches your requirements perfectly!</p>
              </div>

              <Card>
                <div className="overflow-hidden rounded-t-xl">
                  <img
                    src={recommendation.image}
                    alt={`${recommendation.brand} ${recommendation.model}`}
                    className="w-full h-64 object-cover"
                  />
                </div>
                <div className="p-8">
                  <h4 className="text-3xl font-bold text-white mb-3">
                    {recommendation.brand} {recommendation.model}
                  </h4>
                  <p className="text-4xl font-bold text-sky-500 mb-6">
                    Rs {(recommendation.price / 100000).toFixed(1)} Lac
                  </p>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-[#0f172a] p-4 rounded-lg">
                      <p className="text-gray-400 text-sm">Engine</p>
                      <p className="text-white font-semibold">{recommendation.engine}</p>
                    </div>
                    <div className="bg-[#0f172a] p-4 rounded-lg">
                      <p className="text-gray-400 text-sm">Mileage</p>
                      <p className="text-white font-semibold">{recommendation.mileage}</p>
                    </div>
                    <div className="bg-[#0f172a] p-4 rounded-lg">
                      <p className="text-gray-400 text-sm">Fuel Type</p>
                      <p className="text-white font-semibold">{recommendation.fuelType}</p>
                    </div>
                    <div className="bg-[#0f172a] p-4 rounded-lg">
                      <p className="text-gray-400 text-sm">Year</p>
                      <p className="text-white font-semibold">{recommendation.year}</p>
                    </div>
                  </div>

                  <Button
                    className="w-full"
                    onClick={() => navigate(`/cars/${recommendation.id}`)}
                  >
                    View Full Details
                  </Button>
                </div>
              </Card>
            </div>
          )}

          {recommendation === null && preferences.budget && (
            <Card hover={false} className="mt-8">
              <div className="p-8 text-center">
                <p className="text-gray-400 text-lg">
                  No cars found matching your preferences. Please adjust your filters and try again.
                </p>
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
