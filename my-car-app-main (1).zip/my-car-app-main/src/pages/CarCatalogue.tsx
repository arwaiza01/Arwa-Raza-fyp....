import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Fuel } from 'lucide-react';
import { cars } from '../data/cars';
import Card from '../components/Card';
import Button from '../components/Button';

export default function CarCatalogue() {
  const navigate = useNavigate();
  const [filters, setFilters] = useState({
    brand: '',
    priceRange: '',
    year: '',
    fuelType: '',
    category: ''
  });

  const brands = [...new Set(cars.map(car => car.brand))];
  const fuelTypes = [...new Set(cars.map(car => car.fuelType))];
  const categories = [...new Set(cars.map(car => car.category))];

  const filteredCars = cars.filter(car => {
    if (filters.brand && car.brand !== filters.brand) return false;
    if (filters.fuelType && car.fuelType !== filters.fuelType) return false;
    if (filters.category && car.category !== filters.category) return false;
    if (filters.year && car.year.toString() !== filters.year) return false;
    if (filters.priceRange) {
      const [min, max] = filters.priceRange.split('-').map(Number);
      if (max && (car.price < min || car.price > max)) return false;
      if (!max && car.price < min) return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-[#0f172a]">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-white mb-8">Car Catalogue</h1>

        <Card hover={false} className="mb-8 p-6">
          <h2 className="text-xl font-bold text-white mb-4">Filters</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            <select
              value={filters.brand}
              onChange={(e) => setFilters({ ...filters, brand: e.target.value })}
              className="bg-[#0f172a] text-white px-4 py-2 rounded-lg border border-gray-700 focus:border-red-500 focus:outline-none"
            >
              <option value="">All Brands</option>
              {brands.map(brand => (
                <option key={brand} value={brand}>{brand}</option>
              ))}
            </select>

            <select
              value={filters.category}
              onChange={(e) => setFilters({ ...filters, category: e.target.value })}
              className="bg-[#0f172a] text-white px-4 py-2 rounded-lg border border-gray-700 focus:border-red-500 focus:outline-none"
            >
              <option value="">All Categories</option>
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>

            <select
              value={filters.priceRange}
              onChange={(e) => setFilters({ ...filters, priceRange: e.target.value })}
              className="bg-[#0f172a] text-white px-4 py-2 rounded-lg border border-gray-700 focus:border-red-500 focus:outline-none"
            >
              <option value="">All Prices</option>
              <option value="0-3000000">Under 30 Lac</option>
              <option value="3000000-5000000">30-50 Lac</option>
              <option value="5000000-8000000">50-80 Lac</option>
              <option value="8000000-999999999">Above 80 Lac</option>
            </select>

            <select
              value={filters.year}
              onChange={(e) => setFilters({ ...filters, year: e.target.value })}
              className="bg-[#0f172a] text-white px-4 py-2 rounded-lg border border-gray-700 focus:border-red-500 focus:outline-none"
            >
              <option value="">All Years</option>
              <option value="2023">2023</option>
              <option value="2022">2022</option>
              <option value="2021">2021</option>
            </select>

            <select
              value={filters.fuelType}
              onChange={(e) => setFilters({ ...filters, fuelType: e.target.value })}
              className="bg-[#0f172a] text-white px-4 py-2 rounded-lg border border-gray-700 focus:border-red-500 focus:outline-none"
            >
              <option value="">All Fuel Types</option>
              {fuelTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredCars.map(car => (
            <Card key={car.id}>
              <div className="overflow-hidden rounded-t-xl">
                <img
                  src={car.image}
                  alt={`${car.brand} ${car.model}`}
                  className="w-full h-48 object-cover transition-transform duration-300 hover:scale-110"
                />
              </div>
              <div className="p-5">
                <h3 className="text-xl font-bold text-white mb-2">
                  {car.brand} {car.model}
                </h3>
                <p className="text-2xl font-bold text-red-500 mb-4">
                  Rs {(car.price / 100000).toFixed(1)} Lac
                </p>
                <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                  <div className="flex items-center space-x-1">
                    <Calendar size={16} />
                    <span>{car.year}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Fuel size={16} />
                    <span>{car.fuelType}</span>
                  </div>
                </div>
                <Button
                  className="w-full"
                  onClick={() => navigate(`/cars/${car.id}`)}
                >
                  View Details
                </Button>
              </div>
            </Card>
          ))}
        </div>

        {filteredCars.length === 0 && (
          <div className="text-center py-20">
            <p className="text-gray-400 text-xl">No cars found matching your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
}
