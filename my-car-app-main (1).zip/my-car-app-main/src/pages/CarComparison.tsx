import { useState } from 'react';
import { GitCompare } from 'lucide-react';
import { cars } from '../data/cars';
import Card from '../components/Card';

export default function CarComparison() {
  const [car1Id, setCar1Id] = useState(cars[0].id);
  const [car2Id, setCar2Id] = useState(cars[1].id);

  const car1 = cars.find(c => c.id === car1Id);
  const car2 = cars.find(c => c.id === car2Id);

  const comparisonFields = [
    { label: 'Price', key: 'price', format: (val: number) => `Rs ${(val / 100000).toFixed(1)} Lac` },
    { label: 'Brand', key: 'brand' },
    { label: 'Model', key: 'model' },
    { label: 'Year', key: 'year' },
    { label: 'Engine', key: 'engine' },
    { label: 'Transmission', key: 'transmission' },
    { label: 'Fuel Type', key: 'fuelType' },
    { label: 'Mileage', key: 'mileage' },
    { label: 'Category', key: 'category' }
  ];

  return (
    <div className="min-h-screen bg-[#0f172a]">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="p-4 bg-sky-500 bg-opacity-10 rounded-full">
              <GitCompare size={64} className="text-sky-500" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-white mb-4">Car Comparison</h1>
          <p className="text-xl text-gray-300">
            Compare two cars side-by-side to make the best decision
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card hover={false}>
            <div className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">Select First Car</h3>
              <select
                value={car1Id}
                onChange={(e) => setCar1Id(e.target.value)}
                className="w-full bg-[#0f172a] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-sky-500 focus:outline-none"
              >
                {cars.map(car => (
                  <option key={car.id} value={car.id}>
                    {car.brand} {car.model} ({car.year})
                  </option>
                ))}
              </select>
            </div>
          </Card>

          <Card hover={false}>
            <div className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">Select Second Car</h3>
              <select
                value={car2Id}
                onChange={(e) => setCar2Id(e.target.value)}
                className="w-full bg-[#0f172a] text-white px-4 py-3 rounded-lg border border-gray-700 focus:border-sky-500 focus:outline-none"
              >
                {cars.map(car => (
                  <option key={car.id} value={car.id}>
                    {car.brand} {car.model} ({car.year})
                  </option>
                ))}
              </select>
            </div>
          </Card>
        </div>

        {car1 && car2 && (
          <Card hover={false}>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="p-6 text-left text-gray-400 font-semibold">Specification</th>
                    <th className="p-6 text-center">
                      <div className="mb-4">
                        <img
                          src={car1.image}
                          alt={`${car1.brand} ${car1.model}`}
                          className="w-full h-48 object-cover rounded-lg mb-4"
                        />
                        <h3 className="text-2xl font-bold text-white">
                          {car1.brand} {car1.model}
                        </h3>
                      </div>
                    </th>
                    <th className="p-6 text-center">
                      <div className="mb-4">
                        <img
                          src={car2.image}
                          alt={`${car2.brand} ${car2.model}`}
                          className="w-full h-48 object-cover rounded-lg mb-4"
                        />
                        <h3 className="text-2xl font-bold text-white">
                          {car2.brand} {car2.model}
                        </h3>
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {comparisonFields.map((field, index) => {
                    const val1 = car1[field.key as keyof typeof car1];
                    const val2 = car2[field.key as keyof typeof car2];
                    const displayVal1 = field.format ? field.format(val1 as number) : val1;
                    const displayVal2 = field.format ? field.format(val2 as number) : val2;

                    return (
                      <tr key={index} className="border-b border-gray-700">
                        <td className="p-6 text-gray-300 font-medium">{field.label}</td>
                        <td className="p-6 text-center text-white font-semibold">{displayVal1}</td>
                        <td className="p-6 text-center text-white font-semibold">{displayVal2}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        <Card hover={false} className="mt-8">
          <div className="p-8 text-center">
            <h3 className="text-2xl font-bold text-white mb-4">Need Help Deciding?</h3>
            <p className="text-gray-300 mb-6">
              Use our AI recommendation system to get personalized suggestions based on your preferences
            </p>
            <a
              href="/ai-recommendation"
              className="inline-block px-8 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-lg transition-colors"
            >
              Get AI Recommendation
            </a>
          </div>
        </Card>
      </div>
    </div>
  );
}
