import { useParams, useNavigate } from 'react-router-dom';
import { GitCompare, Brain, Wrench, ArrowLeft } from 'lucide-react';
import { cars } from '../data/cars';
import Card from '../components/Card';
import Button from '../components/Button';

export default function CarDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const car = cars.find(c => c.id === id);

  if (!car) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Car Not Found</h1>
          <Button onClick={() => navigate('/cars')}>Back to Catalogue</Button>
        </div>
      </div>
    );
  }

  const specifications = [
    { label: 'Brand', value: car.brand },
    { label: 'Model', value: car.model },
    { label: 'Year', value: car.year },
    { label: 'Engine', value: car.engine },
    { label: 'Transmission', value: car.transmission },
    { label: 'Fuel Type', value: car.fuelType },
    { label: 'Mileage', value: car.mileage },
    { label: 'Category', value: car.category }
  ];

  return (
    <div className="min-h-screen bg-[#0f172a]">
      <div className="container mx-auto px-4 py-8">
        <button
          onClick={() => navigate('/cars')}
          className="flex items-center space-x-2 text-gray-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Catalogue</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card hover={false}>
            <img
              src={car.image}
              alt={`${car.brand} ${car.model}`}
              className="w-full h-96 object-cover rounded-xl"
            />
          </Card>

          <div>
            <h1 className="text-4xl font-bold text-white mb-4">
              {car.brand} {car.model}
            </h1>
            <p className="text-5xl font-bold text-red-500 mb-6">
              Rs {(car.price / 100000).toFixed(1)} Lac
            </p>

            <div className="space-y-4 mb-8">
              <Button
                className="w-full flex items-center justify-center space-x-2"
                onClick={() => navigate('/compare')}
              >
                <GitCompare size={20} />
                <span>Compare Cars</span>
              </Button>
              <Button
                variant="secondary"
                className="w-full flex items-center justify-center space-x-2"
                onClick={() => navigate('/ai-recommendation')}
              >
                <Brain size={20} />
                <span>Get AI Suggestion</span>
              </Button>
              <Button
                className="w-full flex items-center justify-center space-x-2 bg-sky-600 hover:bg-sky-700"
                onClick={() => navigate('/mechanics')}
              >
                <Wrench size={20} />
                <span>Find Mechanic</span>
              </Button>
            </div>
          </div>
        </div>

        <Card hover={false}>
          <div className="p-8">
            <h2 className="text-3xl font-bold text-white mb-6">Specifications</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {specifications.map((spec, index) => (
                <div key={index} className="flex justify-between items-center border-b border-gray-700 pb-4">
                  <span className="text-gray-400 font-medium">{spec.label}</span>
                  <span className="text-white font-semibold">{spec.value}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>

        <Card hover={false} className="mt-8">
          <div className="p-8">
            <h2 className="text-3xl font-bold text-white mb-4">About This Car</h2>
            <p className="text-gray-300 leading-relaxed">
              The {car.brand} {car.model} is a premium {car.category.toLowerCase()} that combines
              style, performance, and reliability. Powered by a {car.engine} engine with {car.transmission} transmission,
              this vehicle offers an impressive fuel economy of {car.mileage}. Perfect for those seeking
              a balance between comfort and efficiency. This {car.year} model comes with modern features
              and is in excellent condition, ready for its next owner.
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
