import { useState } from 'react';
import { Car, Users, Wrench, TrendingUp } from 'lucide-react';
import Sidebar from '../components/Sidebar';
import StatCard from '../components/StatCard';
import Card from '../components/Card';
import { cars } from '../data/cars';
import { mechanics } from '../data/mechanics';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div>
            <h1 className="text-4xl font-bold text-white mb-8">Dashboard Overview</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <StatCard
                title="Total Cars"
                value={cars.length}
                icon={Car}
                color="text-red-500"
              />
              <StatCard
                title="Total Users"
                value="1,234"
                icon={Users}
                color="text-sky-500"
              />
              <StatCard
                title="Mechanics"
                value={mechanics.length}
                icon={Wrench}
                color="text-green-500"
              />
              <StatCard
                title="Monthly Growth"
                value="+12%"
                icon={TrendingUp}
                color="text-yellow-500"
              />
            </div>

            <Card hover={false}>
              <div className="p-6">
                <h2 className="text-2xl font-bold text-white mb-6">Recent Listings</h2>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-700">
                        <th className="text-left py-3 px-4 text-gray-400 font-semibold">Car</th>
                        <th className="text-left py-3 px-4 text-gray-400 font-semibold">Price</th>
                        <th className="text-left py-3 px-4 text-gray-400 font-semibold">Year</th>
                        <th className="text-left py-3 px-4 text-gray-400 font-semibold">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {cars.slice(0, 6).map(car => (
                        <tr key={car.id} className="border-b border-gray-700">
                          <td className="py-4 px-4 text-white">
                            {car.brand} {car.model}
                          </td>
                          <td className="py-4 px-4 text-white">
                            Rs {(car.price / 100000).toFixed(1)} Lac
                          </td>
                          <td className="py-4 px-4 text-white">{car.year}</td>
                          <td className="py-4 px-4">
                            <span className="px-3 py-1 bg-green-500 bg-opacity-10 text-green-500 rounded-full text-sm font-medium">
                              Active
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </Card>
          </div>
        );

      case 'cars':
        return (
          <div>
            <h1 className="text-4xl font-bold text-white mb-8">Manage Cars</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {cars.map(car => (
                <Card key={car.id}>
                  <img
                    src={car.image}
                    alt={`${car.brand} ${car.model}`}
                    className="w-full h-48 object-cover rounded-t-xl"
                  />
                  <div className="p-4">
                    <h3 className="text-xl font-bold text-white mb-2">
                      {car.brand} {car.model}
                    </h3>
                    <p className="text-red-500 font-bold mb-4">
                      Rs {(car.price / 100000).toFixed(1)} Lac
                    </p>
                    <div className="flex gap-2">
                      <button className="flex-1 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg transition-colors">
                        Edit
                      </button>
                      <button className="flex-1 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors">
                        Delete
                      </button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 'approve':
        return (
          <div>
            <h1 className="text-4xl font-bold text-white mb-8">Approve Listings</h1>
            <Card hover={false}>
              <div className="p-6">
                <div className="space-y-4">
                  {cars.slice(0, 5).map((car, index) => (
                    <div key={car.id} className="flex items-center justify-between p-4 bg-[#0f172a] rounded-lg">
                      <div className="flex items-center space-x-4">
                        <img
                          src={car.image}
                          alt={`${car.brand} ${car.model}`}
                          className="w-20 h-20 object-cover rounded-lg"
                        />
                        <div>
                          <h3 className="text-white font-bold">
                            {car.brand} {car.model}
                          </h3>
                          <p className="text-gray-400">
                            Rs {(car.price / 100000).toFixed(1)} Lac
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button className="px-6 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors">
                          Approve
                        </button>
                        <button className="px-6 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors">
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>
          </div>
        );

      case 'mechanics':
        return (
          <div>
            <h1 className="text-4xl font-bold text-white mb-8">Manage Mechanics</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mechanics.map(mechanic => (
                <Card key={mechanic.id}>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2">{mechanic.name}</h3>
                    <p className="text-gray-400 mb-2">{mechanic.location}</p>
                    <p className="text-gray-400 mb-4">{mechanic.phone}</p>
                    <div className="flex gap-2">
                      <button className="flex-1 px-4 py-2 bg-sky-500 hover:bg-sky-600 text-white rounded-lg transition-colors">
                        Edit
                      </button>
                      <button className="flex-1 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors">
                        Remove
                      </button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        );

      case 'users':
        return (
          <div>
            <h1 className="text-4xl font-bold text-white mb-8">User Management</h1>
            <Card hover={false}>
              <div className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-700">
                        <th className="text-left py-3 px-4 text-gray-400 font-semibold">Name</th>
                        <th className="text-left py-3 px-4 text-gray-400 font-semibold">Email</th>
                        <th className="text-left py-3 px-4 text-gray-400 font-semibold">Role</th>
                        <th className="text-left py-3 px-4 text-gray-400 font-semibold">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {['John Doe', 'Jane Smith', 'Ali Ahmed', 'Sara Khan', 'Ahmed Malik'].map((name, idx) => (
                        <tr key={idx} className="border-b border-gray-700">
                          <td className="py-4 px-4 text-white">{name}</td>
                          <td className="py-4 px-4 text-white">
                            {name.toLowerCase().replace(' ', '.')}@example.com
                          </td>
                          <td className="py-4 px-4 text-white">User</td>
                          <td className="py-4 px-4">
                            <span className="px-3 py-1 bg-green-500 bg-opacity-10 text-green-500 rounded-full text-sm font-medium">
                              Active
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] flex">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <div className="flex-1 p-8">
        {renderContent()}
      </div>
    </div>
  );
}
