import { useNavigate } from 'react-router-dom';
import { Brain, MapPin, GitCompare, Shield } from 'lucide-react';
import Button from '../components/Button';
import Card from '../components/Card';

export default function Landing() {
  const navigate = useNavigate();

  const features = [
    {
      icon: Brain,
      title: 'AI Car Recommendation',
      description: 'Get personalized car suggestions based on your budget and preferences using advanced AI algorithms.'
    },
    {
      icon: MapPin,
      title: 'Mechanic Locator',
      description: 'Find trusted mechanics near you with expertise in specific car issues and services.'
    },
    {
      icon: GitCompare,
      title: 'Car Comparison',
      description: 'Compare multiple cars side-by-side to make informed purchasing decisions.'
    },
    {
      icon: Shield,
      title: 'Trusted Listings',
      description: 'Browse verified car listings with detailed specifications and competitive pricing.'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#0f172a] to-[#1f2937]">
      <div className="container mx-auto px-4 py-20">
        <div className="text-center mb-20">
          <h1 className="text-6xl md:text-7xl font-bold text-white mb-6 animate-fade-in">
            Virtual Car Showroom
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-10">
            Explore, Compare & Get AI-Based Car Recommendations
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button onClick={() => navigate('/cars')}>
              Explore Cars
            </Button>
            <Button variant="secondary" onClick={() => navigate('/ai-recommendation')}>
              Get AI Recommendation
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index}>
                <div className="p-6 text-center">
                  <div className="flex justify-center mb-4">
                    <div className="p-4 bg-red-500 bg-opacity-10 rounded-lg">
                      <Icon size={40} className="text-red-500" />
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              </Card>
            );
          })}
        </div>

        <div className="mt-20 text-center">
          <Card hover={false}>
            <div className="p-12">
              <h2 className="text-4xl font-bold text-white mb-4">Ready to find your dream car?</h2>
              <p className="text-gray-300 text-lg mb-8">
                Start your journey with our AI-powered recommendations and expert insights
              </p>
              <Button onClick={() => navigate('/cars')}>
                Browse Our Collection
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
