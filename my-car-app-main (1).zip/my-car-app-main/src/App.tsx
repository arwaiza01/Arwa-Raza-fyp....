import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Landing from './pages/Landing';
import CarCatalogue from './pages/CarCatalogue';
import CarDetails from './pages/CarDetails';
import AIRecommendation from './pages/AIRecommendation';
import MechanicLocator from './pages/MechanicLocator';
import CarComparison from './pages/CarComparison';
import AdminDashboard from './pages/AdminDashboard';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#0f172a]">
        <Routes>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route
            path="/*"
            element={
              <>
                <Navbar />
                <Routes>
                  <Route path="/" element={<Landing />} />
                  <Route path="/cars" element={<CarCatalogue />} />
                  <Route path="/cars/:id" element={<CarDetails />} />
                  <Route path="/ai-recommendation" element={<AIRecommendation />} />
                  <Route path="/mechanics" element={<MechanicLocator />} />
                  <Route path="/compare" element={<CarComparison />} />
                </Routes>
                <Footer />
              </>
            }
          />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
