export interface Mechanic {
  id: string;
  name: string;
  expertise: string[];
  phone: string;
  location: string;
  rating: number;
  experience: string;
}

export const mechanics: Mechanic[] = [
  {
    id: '1',
    name: 'Ali Motors',
    expertise: ['Engine', 'Transmission', 'Electrical'],
    phone: '+92 300 1234567',
    location: 'Lahore',
    rating: 4.8,
    experience: '15 years'
  },
  {
    id: '2',
    name: 'Hassan Auto Workshop',
    expertise: ['Brakes', 'Suspension', 'Body Work'],
    phone: '+92 321 9876543',
    location: 'Karachi',
    rating: 4.5,
    experience: '10 years'
  },
  {
    id: '3',
    name: 'Premium Car Care',
    expertise: ['Engine', 'Brakes', 'AC Repair'],
    phone: '+92 333 5551234',
    location: 'Islamabad',
    rating: 4.9,
    experience: '12 years'
  },
  {
    id: '4',
    name: 'Express Auto Service',
    expertise: ['Electrical', 'Engine', 'Diagnostics'],
    phone: '+92 301 7778888',
    location: 'Lahore',
    rating: 4.6,
    experience: '8 years'
  },
  {
    id: '5',
    name: 'Reliable Mechanics',
    expertise: ['Brakes', 'Transmission', 'Oil Change'],
    phone: '+92 311 4445566',
    location: 'Karachi',
    rating: 4.7,
    experience: '20 years'
  },
  {
    id: '6',
    name: 'City Auto Workshop',
    expertise: ['Engine', 'Suspension', 'Alignment'],
    phone: '+92 345 2223344',
    location: 'Islamabad',
    rating: 4.4,
    experience: '7 years'
  },
  {
    id: '7',
    name: 'Tech Motors',
    expertise: ['Electrical', 'AC Repair', 'Diagnostics'],
    phone: '+92 312 6667788',
    location: 'Lahore',
    rating: 4.8,
    experience: '11 years'
  },
  {
    id: '8',
    name: 'Master Auto Repair',
    expertise: ['Engine', 'Brakes', 'Body Work'],
    phone: '+92 322 9998877',
    location: 'Karachi',
    rating: 4.9,
    experience: '18 years'
  }
];
