export interface Car {
  id: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  fuelType: string;
  transmission: string;
  engine: string;
  mileage: string;
  image: string;
  category: string;
}

export const cars: Car[] = [
  {
    id: '1',
    brand: 'Toyota',
    model: 'Corolla',
    year: 2023,
    price: 4500000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engine: '1.8L 4-Cylinder',
    mileage: '14 km/l',
    image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Sedan'
  },
  {
    id: '2',
    brand: 'Honda',
    model: 'Civic',
    year: 2023,
    price: 5200000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engine: '1.5L Turbo',
    mileage: '16 km/l',
    image: 'https://images.pexels.com/photos/337909/pexels-photo-337909.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Sedan'
  },
  {
    id: '3',
    brand: 'Suzuki',
    model: 'Alto',
    year: 2023,
    price: 2300000,
    fuelType: 'Petrol',
    transmission: 'Manual',
    engine: '660cc',
    mileage: '22 km/l',
    image: 'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Hatchback'
  },
  {
    id: '4',
    brand: 'Toyota',
    model: 'Fortuner',
    year: 2023,
    price: 11500000,
    fuelType: 'Diesel',
    transmission: 'Automatic',
    engine: '2.8L Diesel',
    mileage: '12 km/l',
    image: 'https://images.pexels.com/photos/1638459/pexels-photo-1638459.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'SUV'
  },
  {
    id: '5',
    brand: 'Honda',
    model: 'City',
    year: 2023,
    price: 4200000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engine: '1.5L i-VTEC',
    mileage: '15 km/l',
    image: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Sedan'
  },
  {
    id: '6',
    brand: 'Suzuki',
    model: 'Swift',
    year: 2023,
    price: 3800000,
    fuelType: 'Petrol',
    transmission: 'Manual',
    engine: '1.2L',
    mileage: '20 km/l',
    image: 'https://images.pexels.com/photos/1319839/pexels-photo-1319839.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Hatchback'
  },
  {
    id: '7',
    brand: 'Kia',
    model: 'Sportage',
    year: 2023,
    price: 8900000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engine: '2.0L Turbo',
    mileage: '11 km/l',
    image: 'https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'SUV'
  },
  {
    id: '8',
    brand: 'Hyundai',
    model: 'Tucson',
    year: 2023,
    price: 9200000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engine: '2.0L',
    mileage: '12 km/l',
    image: 'https://images.pexels.com/photos/3874344/pexels-photo-3874344.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'SUV'
  },
  {
    id: '9',
    brand: 'Toyota',
    model: 'Yaris',
    year: 2023,
    price: 3900000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engine: '1.3L',
    mileage: '18 km/l',
    image: 'https://images.pexels.com/photos/707046/pexels-photo-707046.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Hatchback'
  },
  {
    id: '10',
    brand: 'Honda',
    model: 'BR-V',
    year: 2023,
    price: 5500000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engine: '1.5L i-VTEC',
    mileage: '13 km/l',
    image: 'https://images.pexels.com/photos/1435515/pexels-photo-1435515.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'SUV'
  },
  {
    id: '11',
    brand: 'Suzuki',
    model: 'Cultus',
    year: 2023,
    price: 3200000,
    fuelType: 'Petrol',
    transmission: 'Manual',
    engine: '1.0L',
    mileage: '20 km/l',
    image: 'https://images.pexels.com/photos/544542/pexels-photo-544542.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Hatchback'
  },
  {
    id: '12',
    brand: 'MG',
    model: 'HS',
    year: 2023,
    price: 7800000,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    engine: '2.0L Turbo',
    mileage: '10 km/l',
    image: 'https://images.pexels.com/photos/3972755/pexels-photo-3972755.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'SUV'
  }
];
