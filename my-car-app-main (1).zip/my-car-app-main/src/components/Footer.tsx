import { Car, Facebook, Twitter, Instagram, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#1f2933] text-gray-300 py-12 mt-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Car size={32} className="text-red-500" />
              <span className="text-2xl font-bold text-white">VCS</span>
            </div>
            <p className="text-sm">
              Virtual Car Showroom - Your trusted AI-powered platform for car recommendations and services.
            </p>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/cars" className="hover:text-red-500 transition-colors">Browse Cars</a></li>
              <li><a href="/ai-recommendation" className="hover:text-red-500 transition-colors">AI Recommendation</a></li>
              <li><a href="/mechanics" className="hover:text-red-500 transition-colors">Find Mechanics</a></li>
              <li><a href="/compare" className="hover:text-red-500 transition-colors">Compare Cars</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-red-500 transition-colors">Help Center</a></li>
              <li><a href="#" className="hover:text-red-500 transition-colors">Contact Us</a></li>
              <li><a href="#" className="hover:text-red-500 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-red-500 transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold mb-4">Connect With Us</h3>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-red-500 transition-colors">
                <Facebook size={24} />
              </a>
              <a href="#" className="hover:text-red-500 transition-colors">
                <Twitter size={24} />
              </a>
              <a href="#" className="hover:text-red-500 transition-colors">
                <Instagram size={24} />
              </a>
              <a href="#" className="hover:text-red-500 transition-colors">
                <Mail size={24} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm">
          <p>&copy; 2024 Virtual Car Showroom. All rights reserved. Final Year Project.</p>
        </div>
      </div>
    </footer>
  );
}
