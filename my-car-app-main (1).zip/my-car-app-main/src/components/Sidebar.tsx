import { Car, CheckCircle, Wrench, Users, LayoutDashboard } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'cars', label: 'Manage Cars', icon: Car },
    { id: 'approve', label: 'Approve Listings', icon: CheckCircle },
    { id: 'mechanics', label: 'Manage Mechanics', icon: Wrench },
    { id: 'users', label: 'Users', icon: Users }
  ];

  return (
    <div className="w-64 bg-[#1f2933] min-h-screen p-6">
      <h2 className="text-white text-2xl font-bold mb-8">Admin Panel</h2>
      <nav className="space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                activeTab === item.id
                  ? 'bg-red-500 text-white'
                  : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Icon size={20} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
