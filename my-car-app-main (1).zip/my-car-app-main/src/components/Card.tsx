interface CardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}

export default function Card({ children, className = '', hover = true }: CardProps) {
  const hoverStyles = hover ? 'hover:transform hover:scale-105 hover:shadow-2xl' : '';

  return (
    <div className={`bg-[#1f2933] rounded-xl shadow-lg transition-all duration-300 ${hoverStyles} ${className}`}>
      {children}
    </div>
  );
}
